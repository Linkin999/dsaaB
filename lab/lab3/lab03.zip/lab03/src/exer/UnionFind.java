package exer;

public class UnionFind {
    // Define whatever data you want.

    public UnionFind( int N ) {
        // Write a constructor if necessary.
    }

    public int find( int p ) {
        // Write a find method if you feel like doint so.
    }

    public boolean isConnected( int p, int q ) {
        // Write code here!
    }
    public void union( int p, int q ) {
        // Write code here!
    }
}
