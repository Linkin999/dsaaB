### What to do with this code:

1, Download algs4.jar from https://algs4.cs.princeton.edu/code/algs4.jar.

2, Put algs4.jar in lib folder.


### Please refer to the following urls:

https://algs4.cs.princeton.edu/

https://algs4.cs.princeton.edu/code/

https://algs4.cs.princeton.edu/code/javadoc
