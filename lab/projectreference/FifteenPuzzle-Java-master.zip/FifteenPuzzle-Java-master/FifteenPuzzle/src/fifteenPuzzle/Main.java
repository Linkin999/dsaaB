package fifteenPuzzle;

import java.awt.Color;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//GameControl.startGame(3);
		new InterfaceWindow();
	}
}
