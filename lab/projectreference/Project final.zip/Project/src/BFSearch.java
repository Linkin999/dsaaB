public class BFSearch {

    private int[][] board;

    private int[] locked;

    private int lockedIndex;
    private Node mirror;
    private Node node;
    private int stepNumber;
    private boolean hasAnswer;
    private boolean hasOperated;
    private Queue queue;
    private int[][] answer;

    private Hash_Value hash_value;

    private String[] steps;

    public String[] getSteps() {
        return steps;
    }

    public BFSearch(int[][] board) {
        this.board = board;

        stepNumber = 0;
        hasAnswer = true;
        String value = ".";
        node = new Node(value, toString(board));
        queue = new Queue(node);

        int m = board[0].length;
        int n = board.length;
        int index = 1;

        answer = new int[n][m];

        if (Main.index22 != 0) {
            locked = new int[4 * Main.index22];
            lockedIndex = 0;
        }

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (index <= m * n - Main.zeros) {
                    answer[i][j] = i * m + j + 1;
                    index++;
                }
            }
        }
    }

    public boolean hasAnswer() {
        //todo:判断是否有解且存储路径
        hash_value = new Hash_Value(toString(board));
        if (toString(answer).equals(toString(board))) {
            return true;
        }
        while (!toString(answer).equals(queue.getFirst().getKey())) {
            hasOperated = false;
            doing();
            if (queue.getFirst().getKey().equals(queue.getEnd().getKey())) {
                hasAnswer = false;
                break;
            }
        }

        steps = answerSteps();

        return hasAnswer;
    }

    public String[] answerSteps() {
        //todo: 将路径转换为标准输出格式
        String steps = new StringBuilder(queue.getFirst().getPath()).reverse().toString();
        String[] output = steps.split("\\.");
        stepNumber = output.length - 2;
        return output;
    }

    public int getStepNumber() {
        //todo: 得到步骤数
        return stepNumber;
    }

    public void swap(int i1, int j1, int i2, int j2) {
        //todo: 交换两个格子
        int temp = board[i1][j1];
        board[i1][j1] = board[i2][j2];
        board[i2][j2] = temp;
    }


    public int[][] copy(String s) {
        //todo: 从哈希值恢复棋盘
        String[] strings = s.split(",|“");
        int[][] copy = new int[board.length][board[0].length];
        for (int i = 0; i < board.length * board[0].length; i++) {
            copy[i / board[0].length][i % board[0].length] = Integer.parseInt(strings[i + 1]);
        }
        return copy;
    }

    public String toString(int[][] board) {
        //todo: 构造哈希值
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[0].length; j++) {
                stringBuilder.append("," + board[i][j]);
            }
        }
        return stringBuilder.toString();
    }

    public void doing() {
        //todo: 完成操作及记录
        board = copy(queue.getFirst().getKey());
        mirror = queue.getFirst();
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[0].length; j++) {
                if (board[i][j] == 0) {
                    if (j != board[0].length - 1 && board[i][j + 1] == 0) {
                        if (i >= 1) writing(i, j, 'D', Main.index12, Main.tile12);
                        if (i <= board.length - 2) writing(i, j, 'U', Main.index12, Main.tile12);
                        if (i >= 2) writing(i, j, 'D', Main.index22, Main.tile22);
                        if (i <= board.length - 3) writing(i, j, 'U', Main.index22, Main.tile22);
                    } else if (i != board.length - 1 && board[i + 1][j] == 0) {
                        if (j >= 1) writing(i, j, 'R', Main.index21, Main.tile21);
                        if (j <= board[0].length - 2) writing(i, j, 'L', Main.index21, Main.tile21);
                        if (j >= 2) writing(i, j, 'R', Main.index22, Main.tile22);
                        if (j <= board[0].length - 3) writing(i, j, 'L', Main.index22, Main.tile22);
                    }
                    if (i >= 1) {
                        boolean used = false;
                        if (i >= 2) {
                            for (int k = 0; k < Main.index21; k++) {
                                if (board[i - 2][j] == Main.tile21[k]) {
                                    swap(i - 1, j, i, j);
                                    swap(i - 2, j, i - 1, j);
                                    boolean written = false;
                                    Node node = hash_value.getHashArray().getEnd();
                                    while (!written) {
                                        if (toString(board).equals(node.getKey())) break;
                                        if (node.getKey().equals(hash_value.getHashArray().getFirst().getKey()) && !board.equals(hash_value.getHashArray().getFirst().getKey())) {
                                            written = true;
                                        }
                                        node = node.getParent();
                                    }
                                    if (written) {
                                        queue.add(new Node("D " + new StringBuilder(Integer.toString(board[i - 1][j])).reverse(), toString(board)));
                                        queue.getEnd().setPath(queue.getEnd().getPath() + "." + queue.getFirst().getPath());
                                        hash_value.addHashArray(toString(board));
                                    }
                                    swap(i - 2, j, i - 1, j);
                                    swap(i - 1, j, i, j);
                                    used = true;
                                    break;
                                }
                            }
                        }
                        if (!used) {
                            swap(i - 1, j, i, j);
                            boolean written = false;
                            Node node = hash_value.getHashArray().getEnd();
                            while (!written) {
                                if (toString(board).equals(node.getKey())) break;
                                if (node.getKey().equals(hash_value.getHashArray().getFirst().getKey()) && !board.equals(hash_value.getHashArray().getFirst().getKey())) {
                                    written = true;
                                }
                                node = node.getParent();
                            }
                            if (written) {
                                boolean isSkipped = false;
                                for (int k = 0; k < 2 * Main.index12 + 2 * Main.index21 + 4 * Main.index22; k++) {
                                    if (Main.skipped[k] == board[i][j] && board[i][j] != 0) isSkipped = true;
                                }
                                if (!isSkipped) {
                                    queue.add(new Node("D " + new StringBuilder(Integer.toString(board[i][j])).reverse(), toString(board)));
                                    queue.getEnd().setPath(queue.getEnd().getPath() + "." + queue.getFirst().getPath());
                                    hash_value.addHashArray(toString(board));
                                }
                            }
                            swap(i - 1, j, i, j);
                        }
                    }
                    if (i <= board.length - 2) {
                        boolean used = false;
                        if (i < board.length - 2) {
                            for (int k = 0; k < Main.index21; k++) {
                                if (board[i + 1][j] == Main.tile21[k]) {
                                    swap(i + 1, j, i, j);
                                    swap(i + 2, j, i + 1, j);
                                    boolean written = false;
                                    Node node = hash_value.getHashArray().getEnd();
                                    while (!written) {
                                        if (toString(board).equals(node.getKey())) break;
                                        if (node.getKey().equals(hash_value.getHashArray().getFirst().getKey()) && !board.equals(hash_value.getHashArray().getFirst().getKey())) {
                                            written = true;
                                        }
                                        node = node.getParent();
                                    }
                                    if (written) {
                                        queue.add(new Node("U " + new StringBuilder(Integer.toString(board[i + 1][j])).reverse(), toString(board)));
                                        queue.getEnd().setPath(queue.getEnd().getPath() + "." + queue.getFirst().getPath());
                                        hash_value.addHashArray(toString(board));
                                    }
                                    swap(i + 2, j, i + 1, j);
                                    swap(i + 1, j, i, j);
                                    used = true;
                                    break;
                                }
                            }
                        }
                        if (!used) {
                            swap(i + 1, j, i, j);
                            boolean written = false;
                            Node node = hash_value.getHashArray().getEnd();
                            while (!written) {
                                if (toString(board).equals(node.getKey())) break;
                                if (node.getKey().equals(hash_value.getHashArray().getFirst().getKey()) && !board.equals(hash_value.getHashArray().getFirst().getKey())) {
                                    written = true;
                                }
                                node = node.getParent();
                            }
                            if (written) {
                                boolean isSkipped = false;
                                for (int k = 0; k < 2 * Main.index12 + 2 * Main.index21 + 4 * Main.index22; k++) {
                                    if (Main.skipped[k] == board[i][j] && board[i][j] != 0) isSkipped = true;

                                }
                                if (!isSkipped) {
                                    queue.add(new Node("U " + new StringBuilder(Integer.toString(board[i][j])).reverse(), toString(board)));
                                    queue.getEnd().setPath(queue.getEnd().getPath() + "." + queue.getFirst().getPath());
                                    hash_value.addHashArray(toString(board));
                                }
                            }
                            swap(i + 1, j, i, j);
                        }
                    }
                    if (j >= 1) {
                        boolean used = false;
                        if (j >= 2) {
                            for (int k = 0; k < Main.index12; k++) {
                                if (board[i][j - 2] == Main.tile12[k]) {
                                    swap(i, j - 1, i, j);
                                    swap(i, j - 2, i, j - 1);
                                    boolean written = false;
                                    Node node = hash_value.getHashArray().getEnd();
                                    while (!written) {
                                        if (toString(board).equals(node.getKey())) break;
                                        if (node.getKey().equals(hash_value.getHashArray().getFirst().getKey()) && !board.equals(hash_value.getHashArray().getFirst().getKey())) {
                                            written = true;
                                        }
                                        node = node.getParent();
                                    }
                                    if (written) {
                                        queue.add(new Node("R " + new StringBuilder(Integer.toString(board[i][j - 1])).reverse(), toString(board)));
                                        queue.getEnd().setPath(queue.getEnd().getPath() + "." + queue.getFirst().getPath());
                                        hash_value.addHashArray(toString(board));
                                    }
                                    swap(i, j - 2, i, j - 1);
                                    swap(i, j - 1, i, j);
                                    used = true;
                                    break;
                                }
                            }
                        }
                        if (!used) {
                            swap(i, j - 1, i, j);
                            boolean written = false;
                            Node node = hash_value.getHashArray().getEnd();
                            while (!written) {
                                if (toString(board).equals(node.getKey())) break;
                                if (node.getKey().equals(hash_value.getHashArray().getFirst().getKey()) && !board.equals(hash_value.getHashArray().getFirst().getKey())) {
                                    written = true;
                                }
                                node = node.getParent();
                            }
                            if (written) {
                                boolean isSkipped = false;
                                for (int k = 0; k < 2 * Main.index12 + 2 * Main.index21 + 4 * Main.index22; k++) {
                                    if (Main.skipped[k] == board[i][j] && board[i][j] != 0) isSkipped = true;
                                }
                                if (!isSkipped) {
                                    queue.add(new Node("R " + new StringBuilder(Integer.toString(board[i][j])).reverse(), toString(board)));
                                    queue.getEnd().setPath(queue.getEnd().getPath() + "." + queue.getFirst().getPath());
                                    hash_value.addHashArray(toString(board));
                                }
                            }
                            swap(i, j - 1, i, j);
                        }
                    }
                    if (j <= board[0].length - 2) {
                        boolean used = false;
                        if (j < board[0].length - 2) {
                            for (int k = 0; k < Main.index12; k++) {
                                if (board[i][j + 1] == Main.tile12[k]) {
                                    swap(i, j + 1, i, j);
                                    swap(i, j + 2, i, j + 1);
                                    boolean written = false;
                                    Node node = hash_value.getHashArray().getEnd();
                                    while (!written) {
                                        if (toString(board).equals(node.getKey())) break;
                                        if (node.getKey().equals(hash_value.getHashArray().getFirst().getKey()) && !board.equals(hash_value.getHashArray().getFirst().getKey())) {
                                            written = true;
                                        }
                                        node = node.getParent();
                                    }
                                    if (written) {
                                        queue.add(new Node("L " + new StringBuilder(Integer.toString(board[i][j])).reverse(), toString(board)));
                                        queue.getEnd().setPath(queue.getEnd().getPath() + "." + queue.getFirst().getPath());
                                        hash_value.addHashArray(toString(board));
                                    }
                                    swap(i, j + 2, i, j + 1);
                                    swap(i, j + 1, i, j);
                                    used = true;
                                    break;
                                }
                            }
                        }
                        if (!used) {
                            swap(i, j + 1, i, j);
                            boolean written = false;
                            Node node = hash_value.getHashArray().getEnd();
                            while (!written) {
                                if (toString(board).equals(node.getKey())) break;
                                if (node.getKey().equals(hash_value.getHashArray().getFirst().getKey()) && !board.equals(hash_value.getHashArray().getFirst().getKey())) {
                                    written = true;
                                }
                                node = node.getParent();
                            }
                            if (written) {
                                boolean isSkipped = false;
                                for (int k = 0; k < 2 * Main.index12 + 2 * Main.index21 + 4 * Main.index22; k++) {
                                    if (Main.skipped[k] == board[i][j] && board[i][j] != 0) isSkipped = true;
                                }
                                if (!isSkipped) {
                                    queue.add(new Node("L " + new StringBuilder(Integer.toString(board[i][j])).reverse(), toString(board)));
                                    queue.getEnd().setPath(queue.getEnd().getPath() + "." + queue.getFirst().getPath());
                                    hash_value.addHashArray(toString(board));
                                }
                            }
                            swap(i, j + 1, i, j);
                        }
                    }
                }
            }
        }
        queue.pop();
    }

    public void writing(int i, int j, char c, int type1, int[] type2) {
        //todo: 操作大格
        int x;
        int y;

        if (type1 == Main.index12 || type1 == Main.index21) {
            if (c == 'D') {
                x = -1;
                y = 0;
            } else if (c == 'U') {
                x = 1;
                y = 0;
            } else if (c == 'R') {
                x = 0;
                y = -1;
            } else {
                x = 0;
                y = 1;
            }
        } else {
            if (c == 'D') {
                x = -2;
                y = 0;
            } else if (c == 'U') {
                x = 2;
                y = 0;
            } else if (c == 'R') {
                x = 0;
                y = -2;
            } else {
                x = 0;
                y = 2;
            }
        }
        if (type1 == Main.index21) {
            for (int k = 0; k < type1; k++) {
                if (board[i + x][j + y] == type2[k]) {
                    swap(i, j + y, i, j);
                    swap(i + 1, j + y, i + 1, j);
                    boolean written = false;
                    Node node = hash_value.getHashArray().getEnd();
                    while (!written) {
                        if (toString(board).equals(node.getKey())) break;
                        if (node.getKey().equals(hash_value.getHashArray().getFirst().getKey()) && !board.equals(hash_value.getHashArray().getFirst().getKey())) {
                            written = true;
                        }
                        node = node.getParent();
                    }
                    if (written) {
                        queue.add(new Node(c + " " + new StringBuilder(Integer.toString(board[i][j])).reverse(), toString(board)));
                        queue.getEnd().setPath(queue.getEnd().getPath() + "." + queue.getFirst().getPath());
                        hash_value.addHashArray(toString(board));
                        hasOperated = true;
                    }
                    swap(i + x, j + y, i, j);
                    swap(i + 1 + x, j + y, i + 1, j);
                    break;
                }
            }
        } else if (type1 == Main.index12) {
            for (int k = 0; k < type1; k++) {
                if (board[i + x][j + y] == type2[k]) {
                    swap(i + x, j + y, i, j);
                    swap(i + x, j + 1 + y, i, j + 1);
                    boolean written = false;
                    Node node = hash_value.getHashArray().getEnd();
                    while (!written) {
                        if (toString(board).equals(node.getKey())) break;
                        if (node.getKey().equals(hash_value.getHashArray().getFirst().getKey()) && !board.equals(hash_value.getHashArray().getFirst().getKey())) {
                            written = true;
                        }
                        node = node.getParent();
                    }
                    if (written) {
                        queue.add(new Node(c + " " + new StringBuilder(Integer.toString(board[i][j])).reverse(), toString(board)));
                        queue.getEnd().setPath(queue.getEnd().getPath() + "." + queue.getFirst().getPath());
                        hash_value.addHashArray(toString(board));
                        hasOperated = true;
                    }
                    swap(i + x, j + y, i, j);
                    swap(i + x, j + y + 1, i, j + 1);
                    break;
                }
            }
        } else {
            for (int k = 0; k < type1; k++) {
                boolean b = false;
                if (c == 'U') {
                    if (board[i + 1][j] == type2[k]) {
                        swap(i + 1, j, i, j);
                        swap(i + 1, j + 1, i, j + 1);
                        swap(i + 2, j, i + 1, j);
                        swap(i + 2, j + 1, i + 1, j + 1);
                        b = true;
                    }
                } else if (c == 'D') {
                    if (board[i - 2][j] == type2[k]) {
                        swap(i - 1, j, i, j);
                        swap(i - 1, j + 1, i, j + 1);
                        swap(i - 2, j, i - 1, j);
                        swap(i - 2, j + 1, i - 1, j + 1);
                        b = true;
                    }
                } else if (c == 'L') {
                    if (board[i][j + 1] == type2[k]) {
                        swap(i, j + 1, i, j);
                        swap(i + 1, j + 1, i + 1, j);
                        swap(i, j + 2, i, j + 1);
                        swap(i + 1, j + 2, i + 1, j + 1);
                        b = true;
                    }
                } else {
                    if (board[i][j - 2] == type2[k]) {
                        swap(i, j - 1, i, j);
                        swap(i + 1, j - 1, i + 1, j);
                        swap(i, j - 2, i, j - 1);
                        swap(i + 1, j - 2, i + 1, j - 1);
                        b = true;
                    }
                }
                if (b) {
                    boolean written = false;
                    Node node = hash_value.getHashArray().getEnd();
                    while (!written) {
                        if (toString(board).equals(node.getKey())) break;
                        if (node.getKey().equals(hash_value.getHashArray().getFirst().getKey()) && !board.equals(hash_value.getHashArray().getFirst().getKey())) {
                            written = true;
                        }
                        node = node.getParent();
                    }
                    if (written) {
                        queue.add(new Node(c + " " + new StringBuilder(Integer.toString(board[i][j])).reverse(), toString(board)));
                        queue.getEnd().setPath(queue.getEnd().getPath() + "." + queue.getFirst().getPath());
                        hash_value.addHashArray(toString(board));
                        hasOperated = true;
                    }
                    if (c == 'U') {
                        swap(i + 1, j, i, j);
                        swap(i + 1, j + 1, i, j + 1);
                        swap(i + 2, j, i + 1, j);
                        swap(i + 2, j + 1, i + 1, j + 1);
                    } else if (c == 'D') {
                        swap(i - 1, j, i, j);
                        swap(i - 1, j + 1, i, j + 1);
                        swap(i - 2, j, i - 1, j);
                        swap(i - 2, j + 1, i - 1, j + 1);
                    } else if (c == 'L') {
                        swap(i, j + 1, i, j);
                        swap(i + 1, j + 1, i + 1, j);
                        swap(i, j + 2, i, j + 1);
                        swap(i + 1, j + 2, i + 1, j + 1);
                    } else {
                        swap(i, j - 1, i, j);
                        swap(i + 1, j - 1, i + 1, j);
                        swap(i, j - 2, i, j - 1);
                        swap(i + 1, j - 2, i + 1, j - 1);
                    }
                    break;
                }
            }
        }
    }
}