import java.util.Scanner;

//todo: 核心思路：使用广度优先搜索，对于一种状态，搜索全部的可行操作，存储在queue中，每次搜索完一种状态后，将其弹出，搜索下一个状态，直到搜索到结果或queue为空为止
public class Main {
    public static int[] tile22;
    public static int[] tile21;
    public static int[] tile12;

    public static int[] skipped;

    public static int index22;
    public static int index12;
    public static int index21;

    public static int zeros = 0;
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int m = in.nextInt();

        int[][] board = new int[n][m];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                board[i][j] = in.nextInt();
                if(board[i][j] == 0) zeros++;
            }
        }

        tile22 = new int[(n / 2) * (m / 2)]; //todo: 存储2*2大格的左上位置的数, 同输入顺序
        tile12 = new int[(n / 2) * m]; //todo: 存储1*2大格的上位置的数
        tile21 = new int[n * (m / 2)]; //todo: 存储2*1大格的左位置的数

        skipped = new int[m * n]; //todo: 存储属于大格的数字

        index22 = 0; //todo: 记录数组中下一个值的插入位置
        index12 = 0; //todo: 记录数组中下一个值的插入位置
        index21 = 0; //todo: 记录数组中下一个值的插入位置

        int numOfSpecial = in.nextInt();

        for (int i = 0; i < numOfSpecial; i++) {
            int temp = in.nextInt();
            String specialTile = in.nextLine();
            int index = 0;
            for (; index < specialTile.length(); index++) {
                if (specialTile.charAt(index) == '*') {
                    if (specialTile.charAt(index - 1) == '1') {
                        skipped[2 * index12 + 4 * index22 + 2 * index21] = temp;
                        skipped[2 * index12 + 4 * index22 + 2 * index21 + 1] = temp + 1;
                        tile12[index12] = temp;

                        index12++;
                    } else if (specialTile.charAt(index + 1) == '1') {
                        skipped[2 * index12 + 4 * index22 + 2 * index21] = temp;
                        skipped[2 * index12 + 4 * index22 + 2 * index21 + 1] = temp + n;
                        tile21[index21] = temp;
                        index21++;
                    } else {
                        skipped[2 * index12 + 4 * index22 + 2 * index21] = temp;
                        skipped[2 * index12 + 4 * index22 + 2 * index21 + 1] = temp + 1;
                        skipped[2 * index12 + 4 * index22 + 2 * index21 + 2] = temp + n;
                        skipped[2 * index12 + 4 * index22 + 2 * index21 + 3] = temp + n + 1;
                        tile22[index22] = temp;
                        index22++;
                    }
                }
            }
        }

        //Todo: Input part ends here.
        BFSearch bfSearch = new BFSearch(board);

        //Todo: Output part starts here.
        if(bfSearch.hasAnswer()){
            System.out.println("Yes");
            System.out.println(bfSearch.getStepNumber());
            for(int i = 0; i < bfSearch.getStepNumber(); i++){
                System.out.println(bfSearch.getSteps()[i + 2]);
            }
        }
        else System.out.println("No");
        //Todo: Output part ends here.
    }
}

