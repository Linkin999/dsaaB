public class Node {
    //todo: 节点类
    private String key; //todo: key = Board;
    private String value; //todo: value = path;
    private Node children;
    private Node parent;

    private String path;
    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public Node getChildren() {
        return children;
    }

    public void setChildren(Node children) {
        this.children = children;
    }

    public Node getParent() {
        return parent;
    }

    public void setParent(Node parent) {
        this.parent = parent;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public Node(String value, String key) {
        this.value = value;
        this.children = null;
        this.parent = null;
        this.key = key;
        this.path = value;
    }

}
