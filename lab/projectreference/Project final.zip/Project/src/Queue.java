public class Queue {

    //todo: 操作顺序队列
    private Node first = new Node("null", "null");
    private Node end = new Node("null", "null");

    private String path;
    private int numOfNodes;

    public Queue(Node node) {
        this.first.setChildren(node);
        node.setParent(this.first);
        this.end.setParent(node);
        node.setChildren(this.end);
        numOfNodes = 1;
    }

    public void add(Node node){

        node.setParent(end.getParent());
        end.getParent().setChildren(node);
        end.setParent(node);
        node.setChildren(end);

        numOfNodes++;
    }

    public void pop(){

        first.setChildren(first.getChildren().getChildren());
        numOfNodes--;
    }

    public Node getFirst(){
        return first.getChildren();
    }

    public Node getEnd() {
        return end.getParent();
    }

}
