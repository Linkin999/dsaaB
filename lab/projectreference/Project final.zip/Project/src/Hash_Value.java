public class Hash_Value {
    // todo: 哈希值队列，哈希值为二维数组的toString()
    private Queue hashArray;

    public Hash_Value(String board){
        hashArray = new Queue(new Node(".", board));
    }

    public void addHashArray(String board) {
        hashArray.add(new Node(".", board));
    }

    public Queue getHashArray() {
        return hashArray;
    }


}
