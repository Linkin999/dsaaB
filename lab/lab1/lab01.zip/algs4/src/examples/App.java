package examples;

import edu.princeton.cs.algs4.StdOut;

public class App {
    public static void main(String[] args) throws Exception {
        StdOut.println("Hello!");
    }
}
