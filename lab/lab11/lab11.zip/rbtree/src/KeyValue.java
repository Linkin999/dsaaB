public class KeyValue<Key, Value> {

    public Key key;
    public Value value;

    public KeyValue( Key k, Value v ) {
        key = k;
        value = v;
    }
    
}
