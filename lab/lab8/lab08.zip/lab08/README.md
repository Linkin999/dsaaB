### What to do with this code:

1, Download algs4.jar from https://algs4.cs.princeton.edu/code/algs4.jar.

2, Put algs4.jar in lib folder.

3, If you are on windows, complete the code and run "run.bat".

4, Otherwise if you are on Linux, run "run.sh".


### Please refer to the following urls:

https://algs4.cs.princeton.edu/

https://algs4.cs.princeton.edu/code/

https://algs4.cs.princeton.edu/code/javadoc
