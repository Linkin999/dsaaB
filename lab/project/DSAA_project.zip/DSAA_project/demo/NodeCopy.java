import edu.princeton.cs.algs4.Queue;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Scanner;

public class NodeCopy {
    int n;
    int m;
    int[][] board = new int[n][m];
    final int neoCount;
    NodeCopy father;
    int[] x0;
    int[] y0;

    // F = G + H
    int f;
    int g;
    int h;


    //初始化Node
    public NodeCopy(int n, int m, int neoCount, NodeCopy father){
        this.n = n;
        this.m = m;
        this.board = new int[n][m];
        this.neoCount = neoCount;
        this.father = father;
        this.x0 = new int[neoCount];
        this.y0 = new int[neoCount];
        this.g = father.g + 1;

    }

    public NodeCopy(int[][] board, NodeCopy father){
        int count = 0;
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[0].length; j++) {
                if(board[i][j] == 0){
                    count++;
                }
            }
        }
        this.neoCount = count;
        int neo = 0;
        this.n = board.length;
        this.m = board[0].length;
        int[][] array = new int[board.length][board[0].length];
        for(int i = 0; i < board.length; i++){
            System.arraycopy(board[i], 0, array[i], 0, board[0].length);
        }
        this.board = array.clone();
        this.father = father;
        this.x0 = new int[count];
        this.y0 = new int[count];
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[0].length; j++) {
                if(board[i][j] == 0){
                    x0[neo] = i;
                    y0[neo] = j;
                    neo++;
                }
            }
        }
    }

    //复制Node
    public NodeCopy(NodeCopy node){
        this.n = node.n;
        this.m = node.m;
        int[][] array=new int[node.board.length][node.board[0].length];
        this.x0 = new int[node.x0.length];
        this.y0 = new int[node.y0.length];
        for(int i = 0; i < node.board.length; i++){
            System.arraycopy(node.board[i], 0, array[i], 0, node.board[0].length);
        }
        this.board = array.clone();
        this.neoCount = node.neoCount;
        this.father = node;
        System.arraycopy(node.x0, 0, this.x0, 0, node.x0.length);
        System.arraycopy(node.y0, 0, this.y0, 0, node.y0.length);
    }

    public static void printState(NodeCopy state){
        for(int i=0;i<state.n;i++){
            for(int j=0;j<state.m;j++){
                System.out.print(state.board[i][j]+" ");
            }
            System.out.print("\n");
        }
        System.out.print("\n");
    }

    public static String arrayToString(NodeCopy state){
        String s="";
        for(int i =0;i<state.n;i++){
            for(int j =0;j<state.m;j++){
                s=s.concat(String.valueOf(state.board[i][j]));//此处可能有问题
            }
        }
        return s;
    }

    public boolean isComplete(){
        int mistake = 0;
        int[] total = new int[n * m];
        for (int i = 0; i < n * m; i++) {
            total[i] = this.board[i / board[0].length][i % board[0].length];
        }
        for (int i = 0; i < total.length - neoCount; i++) {
            if(total[i] != i + 1){
                mistake++;
            }
        }
        for (int i = total.length - neoCount; i < total.length; i++) {
            if (total[i] != 0){
                mistake++;
            }
        }
        return mistake == 0;
    }

    public Queue<NodeCopy> findNext(PriorityQueue<NodeCopy> open){
        NodeCopy currentState = this;
        Queue<NodeCopy> output = null;

        for (int i = 0; i < currentState.x0.length; i++) {
            int x = currentState.x0[i];
            int y = currentState.y0[i];

            //上面能不能换
            if(x - 1 >= 0 && currentState.board[x - 1][y] != 0){
                NodeCopy next = new NodeCopy(currentState);

                //更新
                next.board[x][y]=next.board[x-1][y];
                next.board[x-1][y]=0;
                next.x0[i]=x-1;
                next.y0[i]=y;

                if(open.contains(arrayToString(next))){

                }
                else{

                }
            }

            //下边能不能换
            if(x+1<=n-1 && currentState.board[x + 1][y] != 0){
                NodeCopy next = new NodeCopy(currentState);

                //更新
                next.board[x][y]=next.board[x+1][y];
                next.board[x+1][y]=0;
                next.x0[i] = x+1;
                next.y0[i] = y;

                if(open.contains(arrayToString(next))){

                }
                else{

                }
            }

            //左边能不能换
            if(y-1>=0 && currentState.board[x][y - 1] != 0){
                NodeCopy next = new NodeCopy(currentState);

                //更新
                next.board[x][y]=next.board[x][y-1];
                next.board[x][y-1]=0;
                next.x0[i] = x;
                next.y0[i] = y-1;

                if(open.contains(arrayToString(next))){

                }
                else{

                }
            }

            //右边能不能换
            if(y+1<=m-1 && currentState.board[x][y + 1] != 0){
                NodeCopy next = new NodeCopy(currentState);

                //更新
                next.board[x][y]=next.board[x][y+1];
                next.board[x][y+1]=0;
                next.x0[i] = x;
                next.y0[i] = y+1;

                if(open.contains(arrayToString(next))){

                }
                else{

                }
            }
        }
        return output;
    }

    public static void main(String[] args) throws FileNotFoundException {
        long start = System.currentTimeMillis();
        File file = new File("data/1.in");
        Scanner scanner = new Scanner(file);
        int N = scanner.nextInt();
        int M = scanner.nextInt();
        int[][] initArray = new int[N][M];
        for(int i=0;i<N;i++){
            for(int j=0;j<M;j++){
                initArray[i][j]=scanner.nextInt();
            }
        }
        scanner.close();
        ArrayList<String> ss=new ArrayList<String>();//判断是否重复
        Queue<NodeCopy> queue = new Queue<NodeCopy>();//要搜索的状态

        //初始状态
        NodeCopy initState = new NodeCopy(initArray, null);

        //将初始状态放入
        ss.add(arrayToString(initState));
        queue.enqueue(initState);

        boolean flag = false;
        NodeCopy ans = null;

        while(!queue.isEmpty()){
            NodeCopy currentState = queue.dequeue();

            if(currentState.isComplete()){
                flag = true;
                ans = currentState;
                break;
            }
            int n = currentState.n;
            int m = currentState.m;

            //目前状态 0所在的位置
            for (int i = 0; i < currentState.x0.length; i++) {
                int x = currentState.x0[i];
                int y = currentState.y0[i];

                //上面能不能换
                if(x - 1 >= 0 && currentState.board[x - 1][y] != 0){
                    NodeCopy next = new NodeCopy(currentState);

                    //更新
                    next.board[x][y]=next.board[x-1][y];
                    next.board[x-1][y]=0;
                    next.x0[i]=x-1;
                    next.y0[i]=y;

                    if(ss.contains(arrayToString(next))){
                        System.out.println("No insert\n");
                    }
                    else{
                        ss.add(arrayToString(next));
                        queue.enqueue(next);
                        printState(next);
                    }
                }

                //下边能不能换
                if(x+1<=n-1 && currentState.board[x + 1][y] != 0){
                    NodeCopy next = new NodeCopy(currentState);

                    //更新
                    next.board[x][y]=next.board[x+1][y];
                    next.board[x+1][y]=0;
                    next.x0[i] = x+1;
                    next.y0[i] = y;

                    if(ss.contains(arrayToString(next))){
                        System.out.println("No insert\n");
                    }
                    else{
                        ss.add(arrayToString(next));
                        queue.enqueue(next);
                        printState(next);
                    }
                }

                //左边能不能换
                if(y-1>=0 && currentState.board[x][y - 1] != 0){
                    NodeCopy next = new NodeCopy(currentState);

                    //更新
                    next.board[x][y]=next.board[x][y-1];
                    next.board[x][y-1]=0;
                    next.x0[i] = x;
                    next.y0[i] = y-1;

                    if(ss.contains(arrayToString(next))){
                        System.out.println("No insert\n");
                    }
                    else{
                        ss.add(arrayToString(next));
                        queue.enqueue(next);
                        printState(next);
                    }
                }

                //右边能不能换
                if(y+1<=m-1 && currentState.board[x][y + 1] != 0){
                    NodeCopy next = new NodeCopy(currentState);

                    //更新
                    next.board[x][y]=next.board[x][y+1];
                    next.board[x][y+1]=0;
                    next.x0[i] = x;
                    next.y0[i] = y+1;

                    if(ss.contains(arrayToString(next))){
                        System.out.println("No insert\n");
                    }
                    else{
                        ss.add(arrayToString(next));
                        queue.enqueue(next);
                        printState(next);
                    }
                }
            }
        }

        if(flag){
            NodeCopy t = ans;
            printState(t);
            t = t.father;

            while(t != null){
                printState(t);
                t = t.father;
            }
        }else{
            System.out.print("No solution\n");
        }
        System.out.print((System.currentTimeMillis() - start)/1000 + " s");
    }
}

