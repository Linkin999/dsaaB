import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Random;
import java.util.Stack;

public class HuaRongDao extends JFrame {
    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public int getCol() {
        return col;
    }

    public void setCol(int col) {
        this.col = col;
    }

    int row;
    int col;
    Stack<int[][]> input;

    public int[][] getDatas() {
        return datas;
    }

    public void setDatas(int[][] datas) {
        this.datas = datas;
    }


    int[][] datas =new int[][]{{1,2,3}, {4,5,6}, {7,8,0},{9,10,11}};

    //HashMap<Integer, int[]> hashMap;
    //HashMap<Integer,HashMap<Integer,int[]>> N;
    JButton up;
    JButton down;
    JButton left;
    JButton right;
    JButton go;
    JButton reset;
    JPanel jPanel;
    int k = 0;

    public HuaRongDao(Stack<int[][]> input){
        this.input = input;
        if(input.isEmpty()){
            JOptionPane.showMessageDialog(this, "No solution");
            System.exit(0);
        }
        setDatas(this.input.pop());
        initFrame();
        paintView();
        addButtonEvent();
        this.setVisible(true);
        setRow(datas.length);
        setCol(datas[0].length);
    }

    //显示窗体方法
    public void initFrame() {
        this.setTitle("数字华容道");
        this.setSize(960, 765);
        this.setDefaultCloseOperation(3);
        this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setAlwaysOnTop(true);
    }

    public void View(){
        JOptionPane.showMessageDialog(this, "游戏胜利！！！");
    }


    //组件设置
    public void paintView() {

        //标题设置
        JLabel title = new JLabel("Numeric Ktloski");
        title.setBounds(354, 27, 232, 57);
        this.add(title);

        //游戏面板设置
        jPanel = new JPanel();
        jPanel.setBounds(150, 114, 480, 480);
        jPanel.setLayout(null);
        //把图片放进去
        for (int i = 0; i < datas.length; i++) {
            for (int j = 0; j < datas[i].length; j++) {
                JLabel picture = new JLabel(new ImageIcon("Image\\" + datas[i][j] + ".png"));
                picture.setBounds(90 * j, 90 * i, 90, 90);
                jPanel.add(picture);
            }
        }
        this.add(jPanel);


        //上下左右按钮、求助、重置按钮
        up = new JButton("棋盘大小");
        up.setBounds(732, 165, 57, 57);
        //this.add(up);
        down = new JButton("下");
        down.setBounds(732, 247, 57, 57);
        //this.add(down);
        left = new JButton("左");
        left.setBounds(650, 247, 57, 57);
        //this.add(left);
        right = new JButton("右");
        right.setBounds(813, 247, 57, 57);
        //this.add(right);
        go = new JButton("go");
        go.setBounds(626, 344, 108, 45);
        this.add(go);
        reset = new JButton("reset");
        reset.setBounds(786, 344, 108, 45);
        //this.add(reset);

        //背景设置
        JLabel background = new JLabel();
        background.setBounds(0, 0, 960, 530);
        this.add(background);
    }

    //编写方法打乱二维数组
    public void upset() {
        Random rd = new Random();
        for (int i = 0; i < datas.length; i++) {
            for (int j = 0; j < datas[i].length; j++) {
                int x = rd.nextInt(datas.length);
                int y = rd.nextInt(datas[x].length);
                int temp = datas[i][j];
                datas[i][j] = datas[x][y];
                datas[x][y] = temp;
            }
        }
        Node data = new Node(datas, null, 0, null);
        this.input = Node.answer(data);
        input.pop();
        repaint();
       /* for (int i = 0; i < datas.length; i++) {
            for (int j = 0; j < datas[i].length; j++) {
                if (datas[i][j] == 0) {
                    hashMap.put(k++, new int[]{i, j});
                }
            }
        }
    */

    }

    //编写方法给按钮添加事件
    public void addButtonEvent() {
        up.addActionListener(e -> {
            //TODO:边界处理

            //TODO:交换元素
            int n = 0;
            int[][] a = new int[row][col];
            for(int i = 0;i < row;i++){
                for (int j = 0;j < col;j++){
                    a[i][j] = n++;
                }
            }
            setDatas(a);
            //重绘画板方法
            repaint();
        });
        down.addActionListener(e -> {
            //TODO:边界处理

            //TODO:交换元素

            //判断是否成功
            if(isSuccess()){
                View();
            }
            //重绘画板方法
            repaint();
        });
        left.addActionListener(e -> {
            //TODO:边界处理

            //TODO:交换元素

            //判断是否成功
            if(isSuccess()){
                View();
            }
            //重绘画板方法
            repaint();
        });
        right.addActionListener(e -> {
            //TODO:边界处理

            //TODO:交换元素

            //判断是否成功
            if(isSuccess()){
                View();
            }
            //重绘画板方法
            repaint();
        });
        reset.addActionListener(e -> {
//                System.out.println("重置");
//            int q = 1;
//            for (int i = 0;i < row;i++){
//                for (int j = 0;j < col;j++){
//                    datas[i][j] = q++;
//                }
//            }
//            int i1 = 0;
//            while (col-k+i1 < col-1){
//                datas[row-1][col-k+i1] = 0;
//                i1++;
//            }
            upset();
            up.setEnabled(true);
            down.setEnabled(true);
            left.setEnabled(true);
            right.setEnabled(true);
        });
        go.addActionListener(e -> {
//                System.out.println("求助");
            //TODO:算法部分
            if(input.isEmpty()){
                View();
                System.exit(0);
            }
            setDatas(input.pop());
            repaint();
        });
    }

    //编写重绘方法
    public void repaint() {
        //移除面板上所有组件
        jPanel.removeAll();

        //重新绘制画板内容
        for (int i = 0; i < datas.length; i++) {
            for (int j = 0; j < datas[i].length; j++) {
                JLabel lb = new JLabel(new ImageIcon("Image\\" + datas[i][j] + ".png"));
                lb.setBounds(90 * j, 90 * i, 90, 90);
                jPanel.add(lb);
            }
        }
        this.add(jPanel);
        //添加到画板上
        jPanel.repaint();
    }

    //是否成功方法
    public boolean isSuccess() {
        int q = 1;
        int[][] winArr = new int[row][col];
        for (int i = 0;i < row;i++){
            for (int j = 0;j < col;j++){
                winArr[i][j] = q++;
            }
        }
        int i1 = 0;
        while (col-k+i1 < col-1){
        winArr[row-1][col-k+i1] = 0;
        i1++;
        }
        for (int i = 0; i < datas.length; i++) {
            for (int j = 0; j < datas[i].length; j++) {
                if (datas[i][j] != winArr[i][j]) {
                    return false;
                }
            }
        }
        return true;
    }
}