import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Test {
    public static void main(String[] args) {
        Map<String, Integer> map1 = new HashMap<String, Integer>();

        String str1 = "1234";
        String str2 = "1234";

        String[] str11 = {"11","11"};
        String[] str22 = {"11","12"};

        map1.put(str1, str1.hashCode());
        map1.put(str2, str2.hashCode());

        int[] a1 = {1,1};
        int[] a2 = {1,1};

        System.out.println(str1.equals(str2));
        System.out.println(str1 == str2);
        System.out.println("\n");

        System.out.println(a1 == a2);
        System.out.println(Arrays.equals(a1, a2));
        System.out.println(Arrays.deepHashCode(str11) == Arrays.deepHashCode(str22));
        System.out.println("\n");

        System.out.println(map1.containsValue(str1.hashCode()));
        System.out.println(map1.containsValue(str1));
        System.out.println(map1.containsKey(str1));
        System.out.println(map1.containsKey(str1));
        System.out.println("\n");

        int[][] array1 = { { 8, 7, 4 }, { 3, 6, 5 }, { 0, 2, 1 } };
        int[][] array2 = { { 8, 4, 0 }, { 6, 7, 5 }, { 3, 2, 1 } };
        System.out.println("Hash array1 " + Arrays.deepHashCode(array1));
        System.out.println("Hash array2 " + Arrays.deepHashCode(array2));

    }


}
