package exercise1;

public class Main {

    public static void sort( DeckQueue deckqueue ) {
        // write your code here.
    }

    public static void main( String[] args ) {
        // write your test here.
    }
}